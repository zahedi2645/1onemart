
#!/usr/bin/env bash
set -euo pipefail

PLAN="${1:-planning/planning.yml}"
REPO="${GITHUB_REPOSITORY:?GITHUB_REPOSITORY env is required}"
: "${GH_TOKEN:?GH_TOKEN env is required}"

echo "Using plan: $PLAN for repo $REPO"

if ! command -v jq >/dev/null 2>&1; then
  echo "jq is required"; exit 1;
fi

echo "Syncing labels ..."
yq -r '.labels[] | @base64' "$PLAN" | while read -r row; do
  name=$(echo "$row" | base64 -d | yq -r '.name')
  color=$(echo "$row" | base64 -d | yq -r '.color // "5319e7"')
  desc=$(echo "$row" | base64 -d | yq -r '.description // ""')
  if [[ -z "$name" || "$name" == "null" ]]; then continue; fi
  gh label create "$name" --color "$color" --description "$desc" --repo "$REPO" 2>/dev/null \
    || gh label edit "$name" --color "$color" --description "$desc" --repo "$REPO"
done

echo "Ensuring sprint labels ..."
yq -r '.sprints[].key' "$PLAN" | while read -r sprint; do
  [[ -z "$sprint" || "$sprint" == "null" ]] && continue
  gh label create "sprint:${sprint}" --color "5319e7" --description "Sprint ${sprint}" --repo "$REPO" 2>/dev/null \
    || gh label edit "sprint:${sprint}" --color "5319e7" --description "Sprint ${sprint}" --repo "$REPO"
done

echo "Syncing issues ..."
yq -r '.sprints[] | @base64' "$PLAN" | while read -r srow; do
  sprint=$(echo "$srow" | base64 -d | yq -r '.key')
  due=$(echo "$srow" | base64 -d | yq -r '.due // ""')
  echo " Sprint ${sprint} (due ${due})"
  echo "$srow" | base64 -d | yq -r '.issues[] | @base64' | while read -r irow; do
    title=$(echo "$irow" | base64 -d | yq -r '.title')
    body=$(echo "$irow" | base64 -d | yq -r '.body // ""')
    labels=$(echo "$irow" | base64 -d | yq -r '.labels // [] | join(",")')
    [[ -z "$title" || "$title" == "null" ]] && continue

    if [[ -n "$sprint" ]]; then
      if [[ -n "$labels" ]]; then
        labels="${labels},sprint:${sprint}"
      else
        labels="sprint:${sprint}"
      fi
    fi

    footer=$'\n\n---\n<!-- managed-by: plan-sync -->'
    if [[ -n "$due" && "$due" != "null" ]]; then
      body="Due: ${due}\n\n${body}${footer}"
    else
      body="${body}${footer}"
    fi

    num=$(gh issue list --repo "$REPO" --search "\"$title\" in:title" --state all --json number,title | jq -r ".[] | select(.title==\"$title\") | .number" | head -n1 || true)
    if [[ -n "$num" ]]; then
      echo "  · Update #$num: $title"
      gh issue edit "$num" --repo "$REPO" --body "$body" >/dev/null
      if [[ -n "$labels" ]]; then
        IFS=',' read -ra arr <<< "$labels"
        for l in "${arr[@]}"; do
          [[ -n "$l" ]] && gh issue edit "$num" --repo "$REPO" --add-label "$l" >/dev/null || true
        done
      fi
    else
      echo "  + Create: $title"
      gh issue create --repo "$REPO" --title "$title" --body "$body" ${labels:+--label "$labels"} >/dev/null
    fi
  done
done

echo "Plan sync completed."
